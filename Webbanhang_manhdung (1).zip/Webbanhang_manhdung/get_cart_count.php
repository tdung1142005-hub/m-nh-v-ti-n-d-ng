<?php
session_start();
echo json_encode(['cart_count' => isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0]);