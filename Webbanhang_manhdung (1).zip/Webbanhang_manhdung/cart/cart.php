<?php
session_start();
include '../config.php';

// Timeout giỏ hàng sau 5 phút không thao tác
$cart_timeout = 5 * 60; // 5 phút
if (isset($_SESSION['cart_created']) && (time() - $_SESSION['cart_created'] > $cart_timeout)) {
    unset($_SESSION['cart']);
    unset($_SESSION['cart_created']);
}
if (isset($_SESSION['cart'])) {
    $_SESSION['cart_created'] = time();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Giỏ hàng của bạn</title>
    <link rel="stylesheet" href="../css/cart.css">
    <style>
    /* Popup thông báo đặt hàng thành công */
    .order-success-popup {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
    }
    .order-success-content {
        background: #fff;
        border-radius: 16px;
        padding: 40px 36px 32px 36px;
        text-align: center;
        box-shadow: 0 8px 32px rgba(80,80,120,0.18);
        max-width: 350px;
        animation: popupShow 0.3s;
    }
    .order-success-content h2 {
        color: #6e44ff;
        margin-bottom: 12px;
        font-size: 1.5rem;
    }
    .order-success-content p {
        color: #333;
        margin-bottom: 24px;
        font-size: 1.1rem;
    }
    .order-success-content .close-popup {
        background: #6e44ff;
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 10px 28px;
        font-size: 1rem;
        cursor: pointer;
        font-weight: bold;
        transition: background 0.2s;
    }
    .order-success-content .close-popup:hover {
        background: #a777e3;
    }
    @keyframes popupShow {
        from { transform: translateY(-40px); opacity: 0;}
        to { transform: translateY(0); opacity: 1;}
    }
    </style>
</head>
<body>
    <?php if (!empty($_SESSION['message']) && $_SESSION['message'] === "🎉 Đặt hàng thành công!"): ?>
        <div class="order-success-popup" id="orderSuccessPopup">
            <div class="order-success-content">
                <h2>🎉 Đặt hàng thành công!</h2>
                <p>Cảm ơn bạn đã mua hàng tại Phone Store.<br>
                <button class="close-popup" onclick="document.getElementById('orderSuccessPopup').style.display='none';">Đóng</button>
            </div>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <header>
        
    </header>

    <div class="cart-container">
        <h2 class="cart-title">🛒 Giỏ hàng của bạn</h2>
        <?php if (empty($_SESSION['cart'])): ?>
            <div class="cart-empty-container">
                <div class="cart-empty-illustration">
                    <img src="https://cdn-icons-png.flaticon.com/512/2038/2038854.png" alt="Giỏ hàng trống">
                </div>
                <p class="cart-empty-message">Không có sản phẩm nào trong giỏ hàng</p>
            </div>
        <?php else: ?>
            <div class="cart-items">
                <?php
                $total = 0;
                foreach ($_SESSION['cart'] as $product_id => $quantity):
                    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
                    $stmt->execute([$product_id]);
                    $product = $stmt->fetch();
                    $subtotal = $product['price'] * $quantity;
                    $total += $subtotal;
                ?>
                <div class="cart-item-box">
                    <div class="cart-item-img">
                        <img src="../images/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    </div>
                    <div class="cart-item-info">
                        <div class="cart-item-title"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="quantity-controls">
                            <form method="POST" action="update_cart.php" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?= $product_id ?>">
                                <button type="submit" name="action" value="decrease">-</button>
                                <span><?= $quantity ?></span>
                                <button type="submit" name="action" value="increase">+</button>
                            </form>
                        </div>
                    </div>
                    <div class="cart-item-price">
                        <span><?= number_format($product['price'], 0, ',', '.') ?>₫</span>
                        <a href="remove_from_cart.php?id=<?= $product_id ?>" class="remove-item remove-item-block">Xóa</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="cart-summary-box">
                <div class="cart-summary-row">
                    <span>Tạm tính (<?= array_sum($_SESSION['cart']) ?> sản phẩm):</span>
                    <span class="cart-summary-price"><?= number_format($total, 0, ',', '.') ?>₫</span>
                </div>
                <div class="cart-summary-row cart-summary-total">
                    <span><b>Tổng tiền</b></span>
                    <span class="cart-summary-price"><b><?= number_format($total, 0, ',', '.') ?>₫</b></span>
                </div>
                <button type="button" class="checkout-btn" onclick="document.getElementById('checkoutModal').style.display='flex';">Đặt hàng</button>
            </div>
        <?php endif; ?>
        <div class="cart-action-row">
            <a href="../huydon/my_orders.php" class="cart-action-btn">Xem đơn hàng của tôi</a>
            <a href="../index.php" class="cart-action-btn">Trở về trang chính</a>
        </div>
    </div>

    <!-- Modal nhập thông tin đặt hàng -->
    <div id="checkoutModal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.3); align-items:center; justify-content:center; z-index:9999;">
        <form method="POST" action="../checkout.php" style="background:#fff; border-radius:14px; padding:32px 28px; min-width:320px; box-shadow:0 8px 32px rgba(80,80,120,0.18); display:flex; flex-direction:column; gap:18px; position:relative;">
            <h2 style="color:#6e44ff; margin-bottom:8px;">Xác nhận đặt hàng</h2>
            <input type="text" name="fullname" placeholder="Họ tên người nhận" required style="padding:10px; border-radius:6px; border:1px solid #ccc;">
            <input type="text" name="phone" placeholder="Số điện thoại" required style="padding:10px; border-radius:6px; border:1px solid #ccc;">
            <input type="text" name="address" placeholder="Địa chỉ nhận hàng" required style="padding:10px; border-radius:6px; border:1px solid #ccc;">
            <select name="payment_method" required style="padding:10px; border-radius:6px; border:1px solid #ccc;">
                <option value="">Chọn phương thức thanh toán</option>
                <option value="cod">Thanh toán khi nhận hàng (COD)</option>
                <option value="bank">Chuyển khoản ngân hàng</option>
            </select>
            <button type="submit" class="checkout-btn" style="margin-top:8px;">Xác nhận đặt hàng</button>
            <button type="button" onclick="document.getElementById('checkoutModal').style.display='none'" style="background:#eee; color:#333; border:none; border-radius:6px; padding:10px; margin-top:4px; cursor:pointer;">Hủy</button>
        </form>
    </div>
</body>
</html>