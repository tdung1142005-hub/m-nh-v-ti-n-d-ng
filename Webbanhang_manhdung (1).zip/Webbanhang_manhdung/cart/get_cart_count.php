<?php
session_start();
$cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
header('Content-Type: application/json');
echo json_encode(['cart_count' => $cart_count]);