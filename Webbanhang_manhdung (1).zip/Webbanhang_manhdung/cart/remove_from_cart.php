<?php
session_start(); 
include '../config.php';
include '../auth.php';
redirectIfNotLoggedIn();

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}
if (empty($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}
header("Location: cart.php");
exit();
?>