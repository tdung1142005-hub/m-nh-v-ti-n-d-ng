DROP DATABASE IF EXISTS shopgm;
CREATE DATABASE shopgm;
USE shopgm;
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 26, 2025 lúc 08:47 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `shopgm`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `total_price` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `special_request` text DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `cancel_reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `username`, `fullname`, `total_price`, `created_at`, `special_request`, `payment_method`, `phone`, `address`, `status`, `cancel_reason`) VALUES
(40, 8, NULL, NULL, 18990000, '2025-05-26 09:19:49', '', 'cod', '0773702618', 'hà nội', 'pending', NULL),
(44, 8, 'Phamvu124', 'Phạm Vũ ', 11990000, '2025-05-26 10:17:34', '', 'cod', '0773702618', 'hà nội ', 'cancelled', 'Thay đổi vị trí địa chỉ'),
(45, 8, 'Phamvu124', 'Phạm Vũ ', 26990000, '2025-05-26 10:31:02', '', 'bank', '0773702618', 'ha noi', 'pending', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(66, 40, 3, 1, 18990000),
(67, 41, 3, 4, 18990000),
(68, 42, 3, 1, 18990000),
(69, 43, 4, 1, 17990000),
(70, 44, 6, 1, 11990000),
(71, 45, 2, 1, 26990000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `screen` varchar(255) DEFAULT NULL,
  `camera` varchar(255) DEFAULT NULL,
  `chip` varchar(255) DEFAULT NULL,
  `ram` varchar(255) DEFAULT NULL,
  `storage` varchar(255) DEFAULT NULL,
  `battery` varchar(255) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `screen`, `camera`, `chip`, `ram`, `storage`, `battery`, `image`, `created_at`) VALUES
(1, 'iPhone 16 Pro Max', 31990000.00, 'Màn hình 6.9\", Chip A18 Pro, Camera 48MP', 'LTPO Super Retina XDR OLED, 120Hz, HDR10, Dolby Vision, 1000 nits (typ), 2000 nits (HBM)\r\n6.9 inches, 1.5K (1320 x 2868 pixels)', '48 MP, f/1.8, 24mm (góc rộng), dual pixel PDAF, sensor-shift OIS\r\n12 MP, f/2.8, 120mm (tele tiềm vọng), dual pixel PDAF, 3D sensor‑shift OIS, zoom quang 5x\r\n48 MP, f/2.2, 13mm (góc siêu rộng), dual pixel PDAF\r\nTOF 3D LiDAR scanner (độ sâu)\r\nQuay phim: 4K@', 'Apple A18 Pro (3 nm)\r\n6 nhân (2x4.04 GHz + 4x2.X GHz)\r\nApple GPU (6 nhân đồ họa)', '8G Ram', '256GB-1TB, NVMe', 'Li-Ion 4685 mAh\r\nSạc nhanh (dây)\r\nSạc 25W (không dây MagSafe)\r\nSạc 15W (không dây Qi2)\r\nSạc 4.5W ngược (dây)', 'iphone16.jpg', '2025-05-22 06:16:21'),
(2, 'Samsung Galaxy S24 Ultra', 26990000.00, 'Bút S-Pen, Camera 200MP,Exynos 2400', 'Dynamic AMOLED 2X Full HD, tần số quét lên tới 120 Hz, độ sáng lên tới 1200 nit, cùng tỷ lệ tương phản cực cao', 'Chính 50 MP & Phụ 12 MP, 10 MP,có thể chụp selfie chất lượng cao hay quay video ổn định ở chất lượng 8K, 4K. ', ' Exynos 2400', '8GB RAM ', '128/256/512GB ROM', '4000mAh', 'samsung24.jpg', '2025-05-22 06:16:21'),
(3, 'Xiaomi 14 Pro', 18990000.00, 'Màn hình AMOLED 120Hz, Camera Leica', 'LTPO AMOLED, 68 tỷ màu, 120Hz, Dolby Vision, HDR10+, 3000 nits (tối đa)\r\n6.73 inches, QHD+ (1440 x 3200 pixels)', '50 MP, f/1.4-f/4.0, 23mm (góc rộng), dual pixel PDAF, Laser AF, OIS, Quay phim: 8K@24fps (HDR), 4K@24/30/60fps (HDR10+, 10-bit Dolby Vision HDR', 'Qualcomm SM8650-AB Snapdragon 8 Gen 3 (4 nm)', '12-16GB, LPDDR5X', '256GB-1TB, UFS 4.0', 'Li-Po 4880 mAh\r\nSạc nhanh 120W, PD3.0, QC4; 100% trong 18 ph (QC)', 'xiaomi14.jpg', '2025-05-22 06:16:21'),
(4, 'OPPO Find X7 Ultra', 17990000.00, 'Camera Hasselblad, Snapdragon 8 Gen 3', 'LTPO AMOLED, 1 tỷ màu, 120Hz, Dolby Vision, HDR10+, 1600 nits (typ), 2600 nits (HBM), 4500 nits (tối đa)\r\n6.82 inches, QHD+ (1440 x 3168 pixels)', '50 MP, f/1.8, 23mm (góc rộng), kích thước 1\", PDAF đa hướng, Laser AF, OIS, Quay phim: 4K@30/60fps, 1080p@30fps, gyro-EIS', 'Qualcomm SM8650-AB Snapdragon 8 Gen 3 (4 nm)\r\n8 nhân (1x3.3 GHz & 5x3.2 GHz & 2x2.3 GHz)', '12-16GB, LPDDR5X', '256-512GB, UFS 4.0', '5000 mAh\r\nSạc 100W. PD (dây), 100% trong 26 ph (QC)\r\nSạc không dây 50W', 'oppox7.jpg', '2025-05-22 06:16:21'),
(5, 'Vivo X100 Pro', 10190000.00, 'Chip Dimensity 9300, Camera ZEISS', 'LTPO AMOLED, 1 tỷ màu, 120Hz, 3000 nits (tối đa)\r\n6.78 inches, 1.5K+ (1260 x 2800 pixels)', '50 MP, f/1.8, 23mm (góc rộng), PDAF, Laser AF, OIS\r\n50 MP, f/2.5, 100mm (tele), PDAF, OIS, zoom quang 4.3x\r\n50 MP, f/2.0, 15mm, 119˚ (góc siêu rộng), AF\r\nQuay phim: 8K, 4K, 1080p, gyro-EIS, Cinematic mode (4K)', 'MediaTek Dimensity 9300 (4 nm)\r\n8 nhân (1x3.25 GHz & 3x2.85 GHz & 4x2.0 GHz)', '12-16GB, LPDDR5X/LPDDR5T', '256GB-1TB, UFS 4.0', 'Li-Po 5400 mAh\r\nSạc nhanh 100W\r\nSạc không dây 50W', 'vivox100.jpg', '2025-05-22 06:16:21'),
(6, 'Realme GT5 Pro', 11990000.00, 'Snapdragon 8 Gen 3, Sạc 100W', 'AMOLED, 1 tỷ màu, 144Hz, HDR10+, 4500 nits (tối đa)\r\n6.78 inches, 1.5K (1264 x 2780 pixels)', '50 MP, f/1.7, 23mm (góc rộng), PDAF đa hướng, OIS\r\n50 MP, f/2.6, 65mm (tele tiềm vọng), PDAF, OIS, zoom quang 2.7x\r\n8 MP, f/2.2, 16mm, 112˚ (góc siêu rộng)\r\nQuay phim: 4K@30/60fps, 1080p@30/60fps, gyro-EIS, Dolby Vision', 'Qualcomm SM8650-AB Snapdragon 8 Gen 3 (4 nm)\r\n8 nhân (1x3.3 GHz & 5x3.2 GHz & 2x2.3 GHz)', '12-16GB, LPDDR5X', '256GB-1TB, UFS 4.0', 'Li-Po 5400 mAh\r\nSạc siêu nhanh 100W, 1-50% trong 12 ph (QC)\r\nSạc không dây 50W', 'realmeGT5.jpg', '2025-05-22 06:16:21'),
(7, 'OnePlus 12', 17990000.00, 'Màn hình 2K 120Hz, Hasselblad Camera', 'LTPO AMOLED, 1 tỷ màu, 120Hz, Dolby Vision, HDR10+, 600 nits (typ), 1600 nits (HBM), 4500 nits (tối đa)\r\n6.82 inches, QHD+ (1440 x 3168 pixels)\r\nTỷ lệ 20:9, mật độ điểm ảnh ~510 ppi\r\nCorning Gorilla Glass Victus 2\r\nAlways-on Display', '50 MP, f/1.6, 23mm (góc rộng), PDAF đa hướng, OIS\r\n64 MP, f/2.6, 70mm (tele kính tiềm vọng), PDAF, OIS, zoom quang 3x\r\n48 MP, f/2.2, 14mm, 114˚ (góc siêu rộng), PDAF\r\nQuay phim: 8K@24fps, 4K@30/60fps, 1080p@30/60/240fps, Auto HDR, gyro-EIS, Dolby Vision', 'Qualcomm SM8650-AB Snapdragon 8 Gen 3 (4 nm)\r\n8 nhân (1x3.3 GHz & 5x3.2 GHz & 2x2.3 GHz)', '12-24GB, LPDDR5X', '256GB-1TB, UFS 4.0', 'Li-Po 5400 mAh\r\nSạc nhanh 100W, PD, QC\r\nSạc 1-100% pin trong 26 ph (QC)\r\nSạc không dây 50W, 1-100% trong 55 ph (QC)', 'oneplus12.jpg', '2025-05-22 06:16:21'),
(8, 'Google Pixel 8 Pro', 22990000.00, 'Android thuần, Tensor G3, AI mạnh mẽ', 'LTPO OLED, 120Hz, HDR10+, 1600 nits (HBM), 2400 nits (tối đa)\r\n6.7 inches, 1344 x 2992 pixels', '50 MP, f/1.7, 25mm (góc rộng), multi-directional PDAF, multi-zone Laser AF, OIS\r\n48 MP, f/2.8, 113mm (tele), dual pixel PDAF, OIS, zoom quang 5x\r\n48 MP, f/2.0, 126˚ (góc siêu rộng), dual pixel PDAF\r\nQuay phim: 4K@30/60fps, 1080p@24/30/60/120/240fps; gyro-', 'Google Tensor G3 (4 nm)\r\n9 nhân (1x3.0 GHz & 4x2.45 GHz & 4x2.15 GHz)', '12GB', '128-256GB, UFS 3.1', 'Li-Ion 5050 mAh\r\nSạc nhanh 30W, PD3.0, PPS\r\nSạc 50% trong 30 ph (QC)\r\nSạc không dây 23W\r\nHỗ trợ sạc ngược không dây', 'pixel8.jpg', '2025-05-22 06:16:21'),
(9, 'ASUS ROG Phone 8', 15990000.00, 'Cấu hình gaming, Snapdragon 8 Gen 3', 'LTPO AMOLED, 1 tỷ màu, 165Hz, HDR10+, 1600 nits (HBM), 2500 nits (tối đa)\r\n6.78 inches, Full HD+ (1080 x 2400 pixels)', '50 MP, f/1.9, 24mm (góc rộng), PDAF, gimbal OIS\r\n32 MP, f/2.4, (tele), PDAF, OIS, zoom quang 3x\r\n13 MP, f/2.2, 13mm, 120˚ (góc siêu rộng)', 'Qualcomm SM8650-AB Snapdragon 8 Gen 3 (4 nm)\r\n8 nhân (1x3.3 GHz & 5x3.2 GHz & 2x2.3 GHz)', '12-24GB, LPDDR5X', '256GB-1TB, UFS 4.0\r\nHỗ trợ NTFS cho bộ nhớ ngoài', 'Li-Po 5500 mAh\r\nSạc nhanh 65W, PD3.0, QC5\r\nSạc 100% trong 39ph (QC)\r\nSạc không dây Qi 15W\r\nSạc ngược qua dây 10W', 'rogphone8.jpg', '2025-05-22 06:16:21'),
(11, 'Redmi Note 13 Pro+', 11990000.00, 'Màn hình 1.5K, Camera 200MP', 'OLED, 68 tỷ màu, 120Hz, Dolby Vision, HDR10+, 1800 nits (tối đa)\r\n6.67 inches, 1.5K (1220 x 2712 pixels), tỷ lệ 20:9\r\nMật độ điểm ảnh ~446 ppi', '200 MP, f/1.7 (góc rộng), PDAF đa hướng, OIS\r\n8 MP, f/2.2, 120˚ (góc siêu rộng)\r\n2 MP, f/2.4 (macro)\r\nQuay phim: 4K@24/30fps, 1080p@30/60/120fps', 'MediaTek Dimensity 7200 Ultra (4 nm)\r\n8 nhân (2x2.8 GHz & 6x2.0 GHz)', '12-16GB, LPDDR5', '256-512GB, UFS 3.1', 'Li-Po 5000 mAh\r\nSạc nhanh 120W\r\nSạc 100% trong 19 ph (QC)', 'redminote13.jpg', '2025-05-22 06:16:21'),
(12, 'Honor Magic6 Pro', 20990000.00, 'Chip Snapdragon 8 Gen 3, Pin 5600mAh', 'LTPO OLED, 6.8 inch, 1280 × 2800 pixel, 	120 Hz, 1 tỷ màu\r\nMàn hình cảm ứng điện dung. Dolby Vision HDR,Màn hình cảm ứng đa điểm', '50 MP, ƒ/1.4, 23 mm ( Góc rộng ), 1.2 μm, 1/1.3\" Kích thước cảm biến\r\n180 MP, ƒ/2.6 ( Periscope telephoto ), 0.56 μm, x2.5 zoom quang học, 1/1.49\r\n50 MP, ƒ/2.0, 13 mm, 122° \r\n2160p @ 24/30/60 fps\r\n1080p @ 30/60/120/240 fps', 'Qualcomm Snapdragon 8 Gen 3, 3.3 GHz, 4 nm', '12GB, 16GB', '256GB, 512GB, 1TB', '5600 mAh, 80 W\r\nSạc có dây ngược\r\nSạc không dây ngược', 'honormagic6.jpg', '2025-05-22 06:16:21'),
(13, 'Samsung Z Fold 6', 35990000.00, 'Thiết kế gập ngang, màn hình AMOLED 7.6\", chip Snapdragon 8 Gen 3, bút S-Pen hỗ trợ ghi chú.', 'Màn hình chính: 7.6\", Dynamic AMOLED 2X, 120Hz, độ sâu màu sắc 16M, 2600nits\r\nMàn hình phụ: 6.3\", 968 x 2376 (HD+), Dynamic AMOLED 2X\r\nKính cường lực Corning® Gorilla® Glass Victus® 2\r\n2160 x 1856 (QXGA+)', 'Camera góc rộng: 50.0 MP, f/1.8, Thu phóng quang học 2x\r\nCamera chụp góc siêu rộng: 12.0 MP, f/2.2\r\nCamera ống kính tele: 10.0 MP, f/2.4, Thu phóng Quang học 3x', 'Snapdragon 8 Gen 3 for Galaxy Tăng lên 42% AI', '12 GB', '\r\n256GB', '4400 mAh', 'fold6.jpg', '2025-05-22 06:26:40'),
(14, 'Xiaomi 15 Pro', 20990000.00, 'Camera cảm biến 1 inch, kính cường lực Gorilla Glass Victus 2, sạc nhanh 120W.', 'LTPO AMOLED, 68 tỷ màu, 120Hz, 120Hz, Dolby Vision, HDR10+, 3200 nits (peak)\r\n6.73 inches, QHD+ (1440 x 3200 pixels)\r\nTỷ lệ 20:9, mật độ điểm ảnh ~522 ppi\r\nKính Shatterproof (2024)', '50 MP, f/1.4, 23mm (góc rộng), 1/1.31\", 1.2µm, dual pixel PDAF, OIS\r\n50 MP, f/2.5, 120mm (tele tiềm vọng), PDAF (30cm - ∞), OIS, zoom quang 5x\r\nQuay phim: 8K@24/30fps (HDR), 4K@24/30/60fps (HDR10+, 10-bit Dolby Vision HDR, 10-bit LOG),', 'Qualcomm SM8750-AB Snapdragon 8 Elite (3 nm)\r\n8 nhân (2x4.32 GHz & 6x3.53 GHz)', '12-16GB, LPDDR5X', '256GB-1TB, UFS 4.0', 'Si/C 6100 mAh\r\nSạc siêu nhanh 90W\r\nSạc không dây 50W\r\nSạc ngược không dây 10W', 'xiaomi15.jpg', '2025-05-22 06:26:40'),
(15, 'iPhone 15 Pro Max', 25990000.00, 'Khung Titanium siêu nhẹ, chip Apple A17 Pro, quay video ProRes chuyên nghiệp.', 'LTPO Super Retina XDR OLED, 120Hz, HDR10, Dolby Vision, 1000 nits (typ), 2000 nits (HBM)\r\n6.7 inches, 1290 x 2796 pixels, tỷ lệ 19.5:9', '48 MP, f/1.8, 24mm (góc rộng), dual pixel PDAF, sensor-shift OIS\r\n12 MP, f/2.8, 120mm (tele kính tiềm vọng) Quay phim: 4K@24/25/30/60fps, 1080p@25/30/60/120/240fps, 10-bit HDR, Dolby Vision HDR (up to 60fps), ProRes, Cinematic mode (4K@24/30fps),', 'Apple A17 Pro (3 nm)\r\n6 nhân (2x3.78 GHz+ 4x)\r\nGPU: Apple GPU (6-lõi đồ họa)', '8GB', '256-512GB, 1TB, NVMe', 'Li-Ion (x) mAh\r\nSạc nhanh có dây 50% trong 30 ph (QC)\r\nSạc không dây (MagSafe) 15W\r\nSạc không dây (Qi) 7.5W  ', 'iphone15promax.jpg', '2025-05-22 06:26:40'),
(22, 'iPhone SE 2024', 11990000.00, 'Màn hình 4.7\", chip A16 Bionic, nhỏ gọn, mạnh mẽ', 'Liquid Retina IPS LCD\r\n6.1 inches, HD+ (828 x 1792 pixels)', '12 MP, f/1.8, 26mm (góc rộng), 1/2.55\", 1.4µm, PDAF, OIS\r\nQuay phim: 4K@24/30/60fps, 1080p@30/60/120/240fps, HDR, stereo sound rec.', 'Apple A15 Bionic (5 nm)\r\n6 nhân (2x3.23 GHz & 4x1.82 GHz)\r\nGPU: Apple GPU (5-nhân đồ họa)', '4GB', '128-256GB\r\nNVMe', '3.200 mAh Li-Ion\r\nSạc nhanh 18W', 'iphonese2024.jpg', '2025-05-23 17:18:19'),
(23, 'Samsung Galaxy A55', 7990000.00, 'Màn hình Super AMOLED 6.6\", camera 50MP', 'Super AMOLED, 1080 x 2400 pixel, tỷ lệ 19,5: 9(mật độ ~390 ppi) đi kèm với tốc độ làm mới 120Hz.', 'Samsung A55 hỗ trợ camera chính 50MP, camera góc siêu rộng 12MP và camera macro 5MP. Bên cạnh đó, camera selfie có ở mặt trước là 32MP. ', 'Exynos 1480, hiệu suất cao có tốc độ 2.75 GHz, tích hợp GPU Xclipse 530 dựa trên RDNA2.', '8GB', '128/256GB', ' 5000mAh đi kèm sạc nhanh 25W. ', 'galaxya55.jpg', '2025-05-23 17:18:19'),
(24, 'Xiaomi 13T Pro', 15990000.00, 'Chip Dimensity 9200+, camera Leica, sạc nhanh 120W', 'AMOLED, 68 tỷ màu, 144Hz, Dolby Vision, HDR10+, 1200 nits (HBM), 2600 nits (tối đa)\r\n6.67 inches, 1.5K (1220 x 2712 pixels)\r\nTỷ lệ 20:9, mật độ điểm ảnh ~446 ppi\r\nCorning Gorilla Glass 5', '50 MP, f/1.9, 24mm (góc rộng), PDAF, OIS\r\n50 MP, f/1.9, 50mm (tele), PDAF, OIS, zoom quang 2x\r\n4K@24/30/60fps, 4K/1080p@30fps HDR10+, 1080p@30/60/120/240fps; 10-bit LOG, gyro-EIS', 'Mediatek Dimensity 9200+ (4 nm)\r\n8 nhân (1x3.35 & 3x3.0 GHz & 4x2.0 GHz)', '12-16GB, LPDDR5X', '256GB-1TB, UFS 4.0', 'Li-Po 5000 mAh\r\nSạc nhanh 120W, PD3.0, QC4\r\nSạc 100% pin trong 19 ph (QC)', 'xiaomi13tpro.jpg', '2025-05-23 17:18:19'),
(25, 'OPPO Reno11 F 5G', 8990000.00, 'Mỏng nhẹ, camera AI, sạc nhanh 67W', 'AMOLED, 1 tỷ màu, 120Hz, HDR10+, 500 nits (typ), 900 nits (HBM), 1100 nits (tối đa)\r\n6.7 inches, Full HD+ (1080 x 2412 pixels)\r\nTỷ lệ 20:9, mật độ điểm ảnh ~394 ppi', '64 MP, f/1.7, 25mm (góc rộng) PDAF\r\n8 MP, f/2.2, 16mm, 112˚ (góc siêu rộng), 1/4.0\", 1.12µm\r\n2 MP, f/2.4 (macro)\r\nQuay phim: 4K@30fps, 1080p@30/60/120/480fps, gyro-EIS', 'Mediatek Dimensity 7050 (6 nm)\r\n8 nhân (2x2.6 GHz & 6x2.0 GHz)\r\nGPU: Mali-G68 MC4', '8GB, LPDDR4x (4266MHz)', '256GB, UFS 3.1', '5000 mAh\r\nSạc nhanh 67W\r\nSuperVOOC 2.0, SuperVOOC, VOOC 3.0 và PD2.0 (9V/1.5A)\r\nHỗ trợ sạc ngược không dây', 'reno11f.jpg', '2025-05-23 17:18:19'),
(26, 'Vivo V30e', 7990000.00, 'Camera chân dung Aura Light, pin 5000mAh', 'AMOLED, 1 tỷ màu, 120Hz, 1300 nits (tối đa)\r\n6.78 inches, Full HD+ (1080 x 2400 pixels)\r\nTỷ lệ 20:9, mật độ điểm ảnh ~388 ppi\r\nSchott Xensation', '50 MP, f/1.8, (góc rộng), PDAF, OIS\r\n8 MP, f/2.2, 120˚ (góc siêu rộng)\r\nQuay phim: 4K@30fps, 1080p@30fps', 'Qualcomm SM6450 Snapdragon 6 Gen 1 (4 nm)\r\n8 nhân (4x2.2 GHz & 4x1.8 GHz)\r\nGPU: Adreno 710', '8GB', '128-256GB', '5500 mAh\r\nSạc nhanh 44W\r\nHỗ trợ sạc ngược có dây', 'vivov30e.jpg', '2025-05-23 17:18:19'),
(27, 'Realme Narzo 60', 5990000.00, 'RAM 8GB, màn hình 90Hz, thiết kế trẻ trung', 'IPS LCD, 120Hz, 550 nits (typ), 680 nits (HBM)\r\n6.72 inches, Full HD+ (1080 x 2400 pixels)\r\nTỷ lệ 20:9, mật độ điểm ảnh ~392 ppi', '50 MP, f/1.8, 27mm (góc rộng), PDAF\r\n2 MP, f/2.4 (độ sâu)\r\nQuay phim: 1080p@30fps', 'Mediatek Dimensity 6100+ (6 nm)\r\n8 nhân (2x2.2 GHz & 6x2.0 GHz)\r\nGPU: Mali-G57 MC2', '4-6GB', '128GB', 'Li-Po 5000 mAh\r\nSạc nhanh 33W\r\nSạc 1-50% pin trong 29 ph (QC)', 'narzo60.jpg', '2025-05-23 17:18:19'),
(28, 'OnePlus Nord CE 3 Lite', 5790000.00, 'Camera 108MP, Snapdragon 695, pin lớn', 'IPS LCD, 120Hz, 550 nits (typ), 680 nits (tối đa)\r\n6.72 inches, Full HD+ (1080 x 2400 pixels), tỷ lệ 20:9\r\nCorning Gorilla Glass', '108 MP, f/1.8, (góc rộng), PDAF\r\n2 MP, f/2.4, (macro)\r\n2 MP, f/2.4, (độ sâu)\r\nQuay phim: 1080p@30fps', 'Qualcomm SM6375 Snapdragon 695 5G (6 nm)\r\n8 nhân (2x2.2 GHz & 6x1.7 GHz)', '8GB, LPDDR4X', '256GB, UFS 2.2', 'Li-Po 5000 mAh\r\nSạc nhanh 67W', 'nordce3lite.jpg', '2025-05-23 17:18:19'),
(29, 'Google Pixel 7a', 10990000.00, 'Camera thông minh, chip Tensor G2, Android 14', 'LTPO AMOLED, 6.7 inches (1440x3120 pixels)\r\n2K, 120Hz, HDR10+', '50MP, f/1.9 (góc rộng)\r\n48MP, f/3.5 (tele)\r\n12MP, f/2.2 (góc siêu rộng)', 'Google Tensor G2 (5 nm)', '8-12GB', '128-512GB', '5000mAh\r\nSạc nhanh 23W', 'pixel7a.jpg', '2025-05-23 17:18:19'),
(30, 'ASUS Zenfone 10', 14990000.00, 'Màn hình nhỏ 5.9\", Snapdragon 8 Gen 2', 'Super AMOLED, 144Hz, HDR10+, 800 nits (HBM), 1100 nits (tối đa)\r\n5.92 inches, FullHD+ (1080 x 2400 pixels), tỷ lệ 20:9\r\nCorning Gorilla Glass Victus\r\nAlways-on display', '50 MP, f/1.9, 24mm (góc rộng), multi-directional PDAF, gimbal OIS\r\n13 MP, f/2.2, 120° (góc siêu rộng)\r\nQuay phim: 8K@24fps, 4K@30/60fps, 1080p@30/60fps; gyro-EIS, HDR', 'Qualcomm SM8550-AB Snapdragon 8 Gen 2 (4 nm)\r\n8 nhân (1x3.2 GHz & 2x2.8 GHz & 2x2.8 GHz & 3x2.0 GHz)', '8-16GB, LPDDR5X', '128-512GB, UFS 4,0', 'Li-Po 4300mAh\r\nSạc nhanh 30W, PD3.0, PPS, QC4\r\nSạc không dây 15W\r\nSạc ngược có dây 5W', 'zenfone10.jpg', '2025-05-23 17:18:19');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `avatar`, `password`, `phone`, `address`) VALUES
(8, 'Phamvu124', 'Phamvu124', 'Pvu17042020@gmail.com', 'uploads/avatar_8.jpg', '$2y$10$KPu9LZglWTYyF2CCeiGbDe0wYvlLK6K8ElGfgJdmKDcopABypQSx2', '0998783828', 'Vĩnh Tuy Hà Nội');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT cho bảng `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
