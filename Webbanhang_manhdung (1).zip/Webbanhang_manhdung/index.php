<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phone Store mini - Sản phẩm chính hãng</title>
    <link rel="stylesheet" href="/ShopVuG/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <i class="fas fa-mobile-alt"></i>
            <span>Phone Store</span>
        </div>
        <!-- Thêm vào trong <header class="header">, trước div tài khoản/giỏ hàng -->
        <form class="search-bar" action="search.php" method="get">
            <input type="text" name="q" placeholder="Tìm kiếm sản phẩm..." required>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
        <div style="display: flex; align-items: center; gap: 24px;">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="account-menu">
                    <a href="#" id="accountBtn" style="color: white; font-size: 1.5rem; display: flex; align-items: center; gap: 10px;">
                        <?php
                        // Hiển thị avatar nếu có, nếu không thì icon mặc định
                        $user_avatar_src = '';
                        if (isset($_SESSION['user']['id'])) {
                            // Lấy avatar từ DB
                            $stmt = $db->prepare("SELECT avatar FROM users WHERE id = ?");
                            $stmt->execute([$_SESSION['user']['id']]);
                            $user_data = $stmt->fetch();
                            if ($user_data && !empty($user_data['avatar']) && file_exists(__DIR__ . '/' . $user_data['avatar'])) {
                                // Đường dẫn đúng và chống cache
                                $user_avatar_src = htmlspecialchars($user_data['avatar']) . '?v=' . time();
                            }
                        }
                        ?>
                        <?php if (!empty($user_avatar_src)): ?>
                            <img src="<?= $user_avatar_src ?>" alt="Avatar" style="width:32px; height:32px; border-radius:50%; object-fit:cover; background:#fff;">
                        <?php else: ?>
                            <i class="fas fa-user-circle"></i>
                        <?php endif; ?>
                        <span style="font-size: 1rem;"><?= htmlspecialchars($_SESSION['user']['username']) ?></span>
                    </a>
                    <div class="account-dropdown" id="accountDropdown" style="display:none;">
                        <a href="/ShopVuG/uploads/profile.php">Tài khoản</a>
                        <a href="logout.php" onclick="return confirm('Bạn chắc chắn muốn đăng xuất?')">Đăng xuất</a>
                    </div>
                </div>
            <?php else: ?>
                <!-- Chưa đăng nhập: hiện icon đăng nhập -->
                <a href="login.php?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>" title="Đăng nhập" style="color: white; font-size: 1.5rem;">
                    <i class="fas fa-sign-in-alt"></i>
                </a>
            <?php endif; ?>
            <div class="cart-icon">
                <a href="cart/cart.php">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count">
                        <?= isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0 ?>
                    </span>
                </a>
            </div>
        </div>
    </header>

    <!-- Banner -->
    <div class="banner-slider" id="bannerSlider">
        <img src="images/banner_1.jpg" alt="Banner" class="banner-slide active">
        <img src="images/banner_2.jpg" alt="Banner 2" class="banner-slide">
        <img src="images/banner_3.jpg" alt="Banner 3" class="banner-slide">
        <img src="images/banner_4.jpg" alt="Banner 4" class="banner-slide">
        <img src="images/banner_5.jpg" alt="Banner 5" class="banner-slide">
        <img src="images/banner_6.jpg" alt="Banner 6" class="banner-slide">
        <img src="images/banner_7.jpg" alt="Banner 7" class="banner-slide">
        <img src="images/banner_8.jpg" alt="Banner 8" class="banner-slide">
        <div class="banner-dots" id="bannerDots"></div>
    </div>

    <!-- Product Grid -->
    <section class="product-section">
        <h2 class="section-title">ĐIỆN THOẠI NỔI BẬT</h2>
        <div class="product-grid">
            <?php
            $stmt = $db->query("SELECT * FROM products");
            while ($row = $stmt->fetch()):
            ?>
            <div class="product-card">
                <div class="product-badge">-10%</div>
                <a href="product_detail.php?id=<?= $row['id'] ?>">
                    <img src="images/<?= $row['image'] ?>" alt="<?= $row['name'] ?>" class="product-image">
                </a>
                <div class="product-info">
                    <a href="product_detail.php?id=<?= $row['id'] ?>" style="text-decoration:none;">
                        <h3 class="product-name"><?= $row['name'] ?></h3>
                    </a>
                    <p class="product-desc"><?= $row['description'] ?></p>
                    <div class="price-box">
                        <span class="current-price"><?= number_format($row['price'], 0, ',', '.') ?> ₫</span>
                        <span class="old-price"><?= number_format($row['price'] * 1.1, 0, ',', '.') ?> ₫</span>
                    </div>
                    <a href="#" class="add-to-cart-btn" data-id="<?= $row['id'] ?>">
                        <i class="fas fa-cart-plus"></i>
                        <span>Thêm vào giỏ</span>
                    </a>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="site-footer" style="background:#fff; margin-top:40px; border-top:1px solid #eee; padding:32px 0 0 0;">
        <div style="max-width:1200px; margin:auto; display:flex; flex-wrap:wrap; gap:40px; justify-content:space-between;">
            <div>
                <strong>Tổng đài hỗ trợ</strong><br>
                Gọi mua: <a href="tel:0773702618" style="color:#1976d2; font-weight:bold;">0773702618</a> (8:00 - 21:30)<br>
                Khiếu nại: <a href="tel:0333651898" style="color:#1976d2; font-weight:bold;">0333651898</a> (8:00 - 21:30)<br>
                Bảo hành: <a href="tel:0978829229" style="color:#1976d2; font-weight:bold;">0978829229</a> (8:00 - 21:00)
            </div>
            <div>
                <strong>Về công ty</strong><br>
                Giới thiệu công ty (MWG.vn)<br>
                Tuyển dụng<br>
                Gửi góp ý, khiếu nại<br>
                Tìm siêu thị (2.957 shop)
            </div>
            <div>
                <strong>Thông tin khác</strong><br>
                Tích điểm Quà tặng VIP<br>
                Lịch sử mua hàng<br>
                Đăng ký bán hàng CTV chiết khấu cao<br>
                Tìm hiểu về mua trả chậm<br>
                Chính sách bảo hành<br>
                Xem thêm
            </div>
            <div>
                <strong>"Nơi công nghệ hội tụ – Dẫn đầu xu hướng"</strong><br>
                <div style="display:flex; flex-wrap:wrap; gap:8px; margin:8px 0;">
                    <span style="background:#222; color:#fff; padding:4px 12px; border-radius:6px; font-size:13px;">TeamCoder</span>
                    <span style="background:#ffe200; color:#222; padding:4px 12px; border-radius:6px; font-size:13px;">Phạm Tuấn Vũ</span>
                    <span style="background:#7ed957; color:#222; padding:4px 12px; border-radius:6px; font-size:13px;">Nguyễn Thị Yến Vi</span>
                    <span style="background:#00bcd4; color:#fff; padding:4px 12px; border-radius:6px; font-size:13px;">Nguyễn Minh Tú</span>
                    <span style="background:#e91e63; color:#fff; padding:4px 12px; border-radius:6px; font-size:13px;">Phạm Ngọc Tú</span>
                    <span style="background:#ff9800; color:#fff; padding:4px 12px; border-radius:6px; font-size:13px;">Nguyễn Xuân Tú</span>

                </div>
                <div style="margin:8px 0;">
                    <span style="margin-right:10px;"><i class="fab fa-facebook"></i> 9999k Fan</span>
                    <span style="margin-right:10px;"><i class="fab fa-youtube"></i> 9999k Đăng ký</span>
                </div>
                <div style="margin:8px 0;">
                    <img src="images/logodtb.jpg" alt="Đã thông báo" style="height:24px;vertical-align:middle;">
                </div>
            </div>
        </div>
        <div style="max-width:1200px; margin:auto; font-size:13px; color:#888; margin-top:24px; padding-bottom:24px;">
            <p>© 2025. Công ty cổ phần Thế Giới Di Động Mini . <br>
        </div>
    </footer>

    <div class="feedback-box">
        <div class="feedback-question">
            Bạn có hài lòng với trải nghiệm tìm kiếm thông tin, sản phẩm trên website không?
        </div>
        <div class="feedback-actions">
            <button class="feedback-btn" id="feedback-happy">
                <span class="emoji">🥰</span>
                <span>Hài lòng</span>
            </button>
            <button class="feedback-btn" id="feedback-sad">
                <span class="emoji">😔</span>
                <span>Không hài lòng</span>
            </button>
        </div>
    </div>
    <style>
    .feedback-box {
        max-width: 420px;
        margin: 36px auto 36px auto;
        background: #fff;
        border: 2px solid #ffd43b;
        border-radius: 10px;
        box-shadow: 0 4px 16px rgba(255,212,67,0.10);
        padding: 22px 28px 18px 28px;
        text-align: left;
        font-size: 1.08rem;
        color: #333;
        position: relative;
    }
    .feedback-question {
        margin-bottom: 18px;
        font-size: 1.07rem;
    }
    .feedback-actions {
        display: flex;
        justify-content: center;
        gap: 38px;
    }
    .feedback-btn {
        background: none;
        border: none;
        outline: none;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        align-items: center;
        font-size: 1.05rem;
        color: #ffc107;
        font-weight: 500;
        transition: color 0.18s;
    }
    .feedback-btn .emoji {
        font-size: 2.1rem;
        margin-bottom: 2px;
    }
    .feedback-btn:hover {
        color: #e09107;
        transform: scale(1.08);
    }
    .feedback-btn:active {
        color: #ff9800;
    }
    </style>
    <script>
    document.getElementById('feedback-happy').onclick = function() {
        alert('Cảm ơn bạn đã đánh giá Hài lòng! 💜');
    };
    document.getElementById('feedback-sad').onclick = function() {
        alert('Cảm ơn bạn đã góp ý! Chúng tôi sẽ cố gắng cải thiện.');
    };
    </script>
    <script src="cart.js"></script>
    <script>
const slides = document.querySelectorAll('.banner-slide');
const dotsContainer = document.getElementById('bannerDots');
let current = 0;
const total = slides.length;

// Tạo dots
for (let i = 0; i < total; i++) {
    const dot = document.createElement('div');
    dot.className = 'banner-dot' + (i === 0 ? ' active' : '');
    dot.addEventListener('click', () => showSlide(i));
    dotsContainer.appendChild(dot);
}
const dots = document.querySelectorAll('.banner-dot');

function showSlide(idx) {
    slides[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = idx;
    slides[current].classList.add('active');
    dots[current].classList.add('active');
}
function nextSlide() {
    showSlide((current + 1) % total);
}
let sliderInterval = setInterval(nextSlide, 3500); // 3.5s chuyển ảnh

// Cho phép hover dừng slider
document.getElementById('bannerSlider').addEventListener('mouseenter', () => clearInterval(sliderInterval));
document.getElementById('bannerSlider').addEventListener('mouseleave', () => sliderInterval = setInterval(nextSlide, 3500));

document.querySelectorAll('.add-to-cart-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        var productId = this.getAttribute('data-id');
        fetch('cart/add_to_cart.php?id=' + productId)
            .then(response => response.json())
            .then(data => {
                // Cập nhật số trên icon giỏ hàng
                document.getElementById('cart-count').textContent = data.cart_count;
                // Có thể hiện thông báo nhỏ ở đây nếu muốn
            });
    });
});
document.getElementById('accountBtn')?.addEventListener('click', function(e) {
    e.preventDefault();
    var dropdown = document.getElementById('accountDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
});
document.addEventListener('click', function(e) {
    var btn = document.getElementById('accountBtn');
    var dropdown = document.getElementById('accountDropdown');
    if (!btn || !dropdown) return;
    if (!btn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.style.display = 'none';
    }
});
function updateCartCount() {
    fetch('cart/get_cart_count.php')
        .then(res => res.json())
        .then(data => {
            document.getElementById('cart-count').textContent = data.cart_count;
        });
}
window.onload = updateCartCount;
</script>
</body>
</html>