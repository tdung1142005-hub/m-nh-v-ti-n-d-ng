<?php
session_start();
include '../config.php';
include '../auth.php';
redirectIfNotLoggedIn();

$user_id = $_SESSION['user']['id'];
$stmt = $db->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Đơn hàng của tôi</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        body {
            background: #f5f5f7;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #222;
            margin: 0;
            padding: 0;
        }

        .orders-outer-container {
            min-height: 100vh;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            background: #f5f5f7;
            padding: 40px 0;
        }

        .orders-container {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(80,80,120,0.10);
            max-width: 800px;
            width: 100%;
            margin: 0 auto;
            padding: 40px 36px 36px 36px;
        }

        .orders-title {
            color: #6e44ff;
            margin-bottom: 24px;
            font-size: 2rem;
            font-weight: 700;
            text-align: center;
        }

        .btn-back-main {
            display: inline-block;
            margin-bottom: 24px;
            background: #6e44ff;
            color: #fff;
            padding: 10px 22px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.05rem;
            transition: background 0.18s;
        }
        .btn-back-main:hover {
            background: #a777e3;
        }

        .no-orders {
            color: #888;
            margin-top: 32px;
            text-align: center;
            font-size: 1.1rem;
        }

        .order-card {
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 2px 12px rgba(80,80,120,0.08);
            padding: 22px 28px;
            margin-bottom: 22px;
            border-left: 6px solid #6e44ff;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: flex-start;
            gap: 18px;
        }

        .order-thumb {
            flex: 0 0 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 18px;
        }
        .order-thumb img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 10px;
            background: #f7f7fa;
            border: 1px solid #eee;
            box-shadow: 0 2px 8px rgba(80,80,120,0.06);
        }
        .order-info {
            flex: 1 1 320px;
            text-align: left;
            font-size: 1.08rem;
        }
        .order-info b {
            color: #6e44ff;
        }
        .order-status {
            font-weight: bold;
            padding: 4px 14px;
            border-radius: 8px;
            background: #f7f5ff;
            color: #6e44ff;
            margin-top: 10px;
            display: inline-block;
        }
        .order-status.cancelled {
            background: #fff0f3;
            color: #e91e63;
        }
        .order-status.completed {
            color: #43b02a;
            background: #eafbe7;
        }
        .order-actions {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-left: auto;
        }
        .order-btn {
            padding: 10px 22px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            font-size: 1rem;
            border: none;
            cursor: pointer;
            transition: background 0.2s;
        }
        .order-cancel {
            background: #e91e63;
            color: #fff;
        }
        .order-cancel:hover {
            background: #ad1457;
        }
        .order-detail {
            background: #6e8efb;
            color: #fff;
        }
        .order-detail:hover {
            background: #a777e3;
        }
        .flash-message {
            background: #e0ffe6;
            color: #2e7d32;
            border: 1px solid #b2ffb2;
            padding: 12px 18px;
            border-radius: 8px;
            margin-bottom: 18px;
            text-align: center;
            font-weight: bold;
        }
        @media (max-width: 600px) {
            .orders-container { padding: 18px 4vw 24px 4vw; }
            .order-card { flex-direction: column; align-items: flex-start; }
            .order-thumb { margin: 0 0 12px 0; }
            .order-actions { width: 100%; margin-left: 0; }
        }
        /* Modal giữ nguyên */
        .cancel-modal-bg {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.3); display: none; align-items: center; justify-content: center; z-index: 9999;
        }
        .cancel-modal {
            background: #fff; border-radius: 12px; padding: 28px 24px; min-width: 320px; box-shadow: 0 8px 32px rgba(80,80,120,0.18);
        }
        .cancel-modal h3 { margin-top: 0; color: #e91e63; }
        .cancel-modal label { display: block; margin-bottom: 8px; }
        .cancel-modal textarea { width: 100%; border-radius: 6px; border: 1px solid #ccc; padding: 8px; }
        .cancel-modal button { margin-top: 12px; }
        .order-status.pending {
            color: #6e44ff;
            background: #f7f5ff;
            padding: 4px 14px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            display: inline-block;
        }
        .order-status.completed {
            color: #43b02a;
            background: #eafbe7;
        }
        .order-status.cancelled {
            color: #e91e63;
            background: #fff0f3;
        }
        .orders-action-row {
            display: flex;
            justify-content: center;
            gap: 18px;
            margin-top: 36px;
        }
        .orders-action-btn {
            display: inline-block;
            background: #6e44ff;
            color: #fff;
            padding: 14px 36px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.08rem;
            box-shadow: 0 2px 8px rgba(110,68,255,0.08);
            text-align: center;
            min-width: 200px;
            transition: background 0.18s, color 0.18s, box-shadow 0.18s;
            border: none;
            outline: none;
        }
        .orders-action-btn:hover, .orders-action-btn:focus {
            background: #a777e3;
            color: #fff;
            box-shadow: 0 4px 16px rgba(110,68,255,0.15);
        }
        .order-delete {
            background: #e74c3c;
            color: #fff;
        }
        .order-delete:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="orders-outer-container">
        <div class="orders-container">
            <?php if (!empty($_SESSION['message'])): ?>
                <div class="flash-message"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
            <?php endif; ?>
            <h2 class="orders-title">Đơn hàng của tôi</h2>
            <?php if (empty($orders)): ?>
                <div class="no-orders">Bạn chưa có đơn hàng nào.</div>
            <?php endif; ?>
            <?php foreach ($orders as $order): ?>
                <?php
                // Lấy ảnh sản phẩm đầu tiên của đơn hàng
                $stmt = $db->prepare("SELECT p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ? LIMIT 1");
                $stmt->execute([$order['id']]);
                $firstProduct = $stmt->fetch();
                $productImg = $firstProduct ? '../images/' . $firstProduct['image'] : 'https://via.placeholder.com/60x60?text=No+Image';
                ?>
                <div class="order-card">
                    <div class="order-thumb">
                        <img src="<?= htmlspecialchars($productImg) ?>" alt="Ảnh sản phẩm" />
                    </div>
                    <div class="order-info">
                        <div>Mã đơn: <b>#<?= $order['id'] ?></b></div>
                        <div>Ngày đặt: <?= $order['created_at'] ?></div>
                        <div>Tổng tiền: <span style="color:#e91e63"><?= number_format($order['total_price'],0,',','.') ?>₫</span></div>
                        <div class="order-status 
                            <?= $order['status']=='cancelled'?'cancelled':'' ?>
                            <?= $order['status']=='pending'?'pending':'' ?>
                            <?= $order['status']=='completed'?'completed':'' ?>
                        ">
                            <?php
                                if ($order['status'] == 'pending') {
                                    echo '<i class="fas fa-clock"></i> Đang phê duyệt';
                                } elseif ($order['status'] == 'completed') {
                                    echo '<i class="fas fa-check-circle"></i> Hoàn thành';
                                } elseif ($order['status'] == 'cancelled') {
                                    echo '<i class="fas fa-times-circle"></i> Đã hủy';
                                } else {
                                    echo htmlspecialchars($order['status']);
                                }
                            ?>
                        </div>
                    </div>
                    <div class="order-actions">
                        <?php if ($order['status'] == 'pending'): ?>
                            <button class="order-btn order-cancel" onclick="openCancelModal(<?= $order['id'] ?>)">Hủy đơn</button>
                        <?php elseif ($order['status'] == 'cancelled'): ?>
                            <form method="POST" action="delete_order.php" style="display:inline;">
                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                <button type="submit" class="order-btn order-delete" onclick="return confirm('Bạn chắc chắn muốn xóa đơn hàng này vĩnh viễn?')">Xóa đơn hàng</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="orders-action-row">
                <a href="../index.php" class="orders-action-btn">Trở về trang chính</a>
                <a href="../cart/cart.php" class="orders-action-btn">Trở về giỏ hàng</a>
            </div>
        </div>
    </div>

    <!-- Modal chọn lý do hủy -->
    <div class="cancel-modal-bg" id="cancelModalBg">
        <form class="cancel-modal" method="POST" action="cancel_order.php" onsubmit="return confirm('Bạn chắc chắn muốn hủy đơn hàng này?')">
            <h3>Chọn lý do hủy đơn hàng</h3>
            <input type="hidden" name="order_id" id="cancelOrderId">
            <label><input type="radio" name="cancel_reason" value="Thay đổi vị trí địa chỉ" required> Thay đổi vị trí địa chỉ</label>
            <label><input type="radio" name="cancel_reason" value="Thay đổi sản phẩm" required> Thay đổi sản phẩm</label>
            <label><input type="radio" name="cancel_reason" value="Không muốn mua nữa" required> Không muốn mua nữa</label>
            <label><input type="radio" name="cancel_reason" value="Lý do khác" required onclick="document.getElementById('otherReason').style.display='block'"> Lý do khác</label>
            <textarea name="other_reason" id="otherReason" placeholder="Nhập lý do khác..." style="display:none; margin-top:8px;"></textarea>
            <div style="margin-top:12px;">
                <button type="submit" style="background:#e91e63; color:#fff; border:none; border-radius:6px; padding:8px 18px;">Xác nhận hủy</button>
                <button type="button" onclick="closeCancelModal()" style="background:#eee; color:#333; border:none; border-radius:6px; padding:8px 18px; margin-left:8px;">Đóng</button>
            </div>
        </form>
    </div>
    <script>
        function openCancelModal(orderId) {
            document.getElementById('cancelOrderId').value = orderId;
            document.getElementById('cancelModalBg').style.display = 'flex';
            document.getElementById('otherReason').style.display = 'none';
            // Reset radio
            let radios = document.querySelectorAll('input[name="cancel_reason"]');
            radios.forEach(r => r.checked = false);
        }
        function closeCancelModal() {
            document.getElementById('cancelModalBg').style.display = 'none';
        }
        // Hiện textarea khi chọn "Lý do khác"
        document.querySelectorAll('input[name="cancel_reason"]').forEach(function(radio) {
            radio.addEventListener('change', function() {
                if (this.value === 'Lý do khác') {
                    document.getElementById('otherReason').style.display = 'block';
                } else {
                    document.getElementById('otherReason').style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>