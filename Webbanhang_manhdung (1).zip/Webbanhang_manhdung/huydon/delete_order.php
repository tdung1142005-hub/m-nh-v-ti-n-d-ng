<?php
session_start();
include '../config.php';
include '../auth.php';

redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $order_id = (int)$_POST['order_id'];
    $user_id = $_SESSION['user']['id'];

    try {
        $db->beginTransaction();

        // Kiểm tra xem đơn hàng có thuộc về user hiện tại và ở trạng thái đã hủy hay không
        $stmt = $db->prepare("SELECT status FROM orders WHERE id = ? AND user_id = ?");
        $stmt->execute([$order_id, $user_id]);
        $order = $stmt->fetch();

        if ($order && $order['status'] === 'cancelled') {
            // Xóa các item liên quan trong bảng order_items
            $stmt = $db->prepare("DELETE FROM order_items WHERE order_id = ?");
            $stmt->execute([$order_id]);

            // Xóa đơn hàng khỏi bảng orders
            $stmt = $db->prepare("DELETE FROM orders WHERE id = ?");
            $stmt->execute([$order_id]);

            $db->commit();
            $_SESSION['message'] = "🗑️ Đơn hàng #{$order_id} đã được xóa thành công!";
        } else {
            $_SESSION['message'] = "❌ Không thể xóa đơn hàng. Đơn hàng không tồn tại hoặc chưa được hủy.";
             $db->rollBack(); // Quay lại trạng thái trước khi có lỗi
        }

    } catch (PDOException $e) {
        $db->rollBack();
        $_SESSION['message'] = "Lỗi khi xóa đơn hàng: " . $e->getMessage();
    }
} else {
    $_SESSION['message'] = "Yêu cầu không hợp lệ.";
}

header('Location: my_orders.php');
exit;
?>