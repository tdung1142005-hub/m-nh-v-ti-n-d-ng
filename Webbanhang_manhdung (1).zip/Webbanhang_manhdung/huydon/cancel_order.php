<?php
session_start();
include '../config.php';
include '../auth.php';
redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['cancel_reason'])) {
    $order_id = (int)$_POST['order_id'];
    $user_id = $_SESSION['user']['id'];
    $reason = $_POST['cancel_reason'];
    if ($reason === 'Lý do khác') {
        $reason = $_POST['other_reason'] ?: 'Lý do khác';
    }
    // Lưu lý do hủy vào cột cancel_reason (nếu chưa có, hãy thêm vào bảng orders)
    $stmt = $db->prepare("UPDATE orders SET status = 'cancelled', cancel_reason = ? WHERE id = ? AND user_id = ? AND status = 'pending'");
    $stmt->execute([$reason, $order_id, $user_id]);
    $_SESSION['message'] = "Đã hủy đơn hàng thành công!";
}
header('Location: my_orders.php');
exit;
?>