// Thêm sản phẩm vào giỏ
function addToCart(productId) {
    fetch('cart/add_to_cart.php?id=' + productId)
        .then(res => res.json())
        .then(data => {
            if (data.cart_count !== undefined) {
                document.getElementById('cart-count').textContent = data.cart_count;
            }
        });
}

// Khi trang được tải, cập nhật số lượng từ session (nếu có)
document.addEventListener('DOMContentLoaded', () => {
    fetch('cart/get_cart_count.php')
        .then(res => res.json())
        .then(data => {
            if (data.cart_count !== undefined) {
                document.getElementById('cart-count').textContent = data.cart_count;
            }
        });
});