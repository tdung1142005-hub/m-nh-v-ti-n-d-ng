<?php
session_start();
include 'config.php';
include 'auth.php';
redirectIfNotLoggedIn();

if (empty($_SESSION['cart'])) {
    header('Location: cart/cart.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user']['id'];
    $total = 0;
    $special_request = $_POST['special_request'] ?? '';
    $payment_method = $_POST['payment_method'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $username = $_SESSION['user']['username'];
    $fullname = $_POST['fullname'];

    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $stmt = $db->prepare("SELECT price FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        if ($product) {
            $total += $product['price'] * $quantity;
        }
    }

    // Lưu đơn hàng, bổ sung 2 trường mới
    $stmt = $db->prepare("INSERT INTO orders (user_id, username, fullname, phone, address, total_price, payment_method, special_request) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $username, $fullname, $phone, $address, $total, $payment_method, $special_request]);
    $order_id = $db->lastInsertId();

    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $stmt = $db->prepare("SELECT price FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        if ($product) {
            $stmt = $db->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            $stmt->execute([$order_id, $product_id, $quantity, $product['price']]);
        }
    }

    unset($_SESSION['cart']);
    $_SESSION['message'] = "🎉 Đặt hàng thành công!";
    header("Location: cart/cart.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thanh toán</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="checkout-container">
        <h2>Thanh toán</h2>
        <form method="POST">
            <h3>Thông tin khách hàng</h3>
            <label>Số điện thoại <span style="color:red">*</span></label><br>
            <input type="text" name="phone" required placeholder="Nhập số điện thoại" style="padding:8px; width:100%; margin-bottom:10px;"><br>
            <label>Địa chỉ nhận hàng <span style="color:red">*</span></label><br>
            <input type="text" name="address" required placeholder="Nhập địa chỉ" style="padding:8px; width:100%; margin-bottom:10px;"><br>
            <label>Họ tên người nhận <span style="color:red">*</span></label><br>
            <input type="text" name="fullname" required placeholder="Nhập họ tên người nhận" style="padding:8px; width:100%; margin-bottom:10px;"><br>

            <h3>Hình thức thanh toán</h3>
            <label><input type="radio" name="payment_method" value="COD" required> Thanh toán khi nhận hàng</label><br>
            <label><input type="radio" name="payment_method" value="Bank"> Chuyển khoản ngân hàng</label><br>

            <button type="submit" class="checkout-btn">Đặt hàng</button>
        </form>
    </div>
</body>
</html>
