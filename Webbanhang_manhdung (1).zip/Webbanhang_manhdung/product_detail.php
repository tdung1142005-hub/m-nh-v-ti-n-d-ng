<?php
session_start();
include 'config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    echo "Không tìm thấy sản phẩm!";
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($product['name']) ?> - Chi tiết sản phẩm</title>
    <link rel="stylesheet" href="/ShopVuG/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .detail-container {
            max-width: 1100px;
            margin: 40px auto 0 auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(80,80,120,0.10);
            padding: 32px 32px 24px 32px;
            display: flex;
            gap: 36px;
            align-items: flex-start;
        }
        .detail-image {
            width: 320px;
            min-width: 220px;
            background: #f7f7fa;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(110,68,255,0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 18px;
        }
        .detail-image img {
            width: 100%;
            max-height: 320px;
            object-fit: contain;
        }
        .detail-info {
            flex: 1;
        }
        .detail-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .detail-price {
            color: #e91e63;
            font-size: 1.5rem;
            font-weight: bold;
            margin: 18px 0 10px 0;
        }
        .detail-desc {
            color: #444;
            font-size: 1.08rem;
            margin-bottom: 18px;
        }
        .detail-actions {
            display: flex;
            gap: 18px;
            margin-top: 24px;
        }
        .back-btn, .add-to-cart-btn {
            padding: 12px 28px;
            border-radius: 22px;
            border: none;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.18s, color 0.18s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .back-btn {
            background: #f2f2ff;
            color: #6e44ff;
            border: 1px solid #a777e3;
        }
        .back-btn:hover {
            background: #e3e3ff;
            color: #4b2fcf;
        }
        .add-to-cart-btn {
            background: linear-gradient(135deg, #f1d03d, #c698fd);
            color: #fff;
            border: none;
        }
        .add-to-cart-btn:hover {
            background: linear-gradient(135deg, #a777e3, #6e8efb);
            color: #fff;
        }
        .spec-table {
            margin-top: 18px;
            border-collapse: collapse;
            width: 100%;
            background: #fafaff;
            border-radius: 8px;
            overflow: hidden;
            font-size: 1rem;
        }
        .spec-table th, .spec-table td {
            padding: 10px 14px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }
        .spec-table th {
            background: #f7f7fa;
            color: #6e44ff;
            width: 180px;
        }
        .spec-table tr:last-child td {
            border-bottom: none;
        }
        @media (max-width: 900px) {
            .detail-container { flex-direction: column; align-items: stretch; }
            .detail-image { width: 100%; max-width: 340px; margin: 0 auto; }
        }
    </style>
</head>
<body>
    <div class="detail-container">
        <div class="detail-image">
            <img src="images/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
        </div>
        <div class="detail-info">
            <div class="detail-title"><?= htmlspecialchars($product['name']) ?></div>
            <div class="detail-desc"><?= htmlspecialchars($product['description']) ?></div>
            <div class="detail-price"><?= number_format($product['price'], 0, ',', '.') ?> ₫</div>
            <!-- Thông số kỹ thuật mẫu, bạn có thể lấy từ DB nếu có -->
            <table class="spec-table">
                <tr><th>Màn hình</th><td><?= htmlspecialchars($product['screen'] ?? 'Đang cập nhật') ?></td></tr>
                <tr><th>Camera</th><td><?= htmlspecialchars($product['camera'] ?? 'Đang cập nhật') ?></td></tr>
                <tr><th>Chip</th><td><?= htmlspecialchars($product['chip'] ?? 'Đang cập nhật') ?></td></tr>
                <tr><th>RAM</th><td><?= htmlspecialchars($product['ram'] ?? 'Đang cập nhật') ?></td></tr>
                <tr><th>Bộ nhớ</th><td><?= htmlspecialchars($product['storage'] ?? 'Đang cập nhật') ?></td></tr>
                <tr><th>Pin</th><td><?= htmlspecialchars($product['battery'] ?? 'Đang cập nhật') ?></td></tr>
            </table>
            <div class="detail-actions">
                <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Quay về trang chính</a>
                <button class="add-to-cart-btn" onclick="addToCart(<?= $product['id'] ?>)">
                    <i class="fas fa-cart-plus"></i> Thêm vào giỏ hàng
                </button>
            </div>
        </div>
    </div>
    <script src="cart.js"></script>
    <script>
    function addToCart(productId) {
        fetch('cart/add_to_cart.php?id=' + productId)
            .then(response => response.json())
            .then(data => {
                alert('Đã thêm vào giỏ hàng!');
                // Nếu muốn cập nhật số lượng trên icon giỏ hàng:
                if (document.getElementById('cart-count')) {
                    document.getElementById('cart-count').textContent = data.cart_count;
                }
            });
    }
    </script>
</body>
</html>