<?php
include 'config.php';

$register_error = null; // Khởi tạo biến lỗi

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Kiểm tra mật khẩu
    if ($password !== $confirm_password) {
        $register_error = "Mật khẩu không khớp";
    } else {
        // Kiểm tra username tồn tại
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->rowCount() > 0) {
            $register_error = "Tên đăng nhập đã tồn tại";
        } else {
            // Hash mật khẩu
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Tạo user mới
            $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)")
               ->execute([$username, $hashed_password]);
            
            header("Location: login.php?registered=1");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Đăng ký</title>
    <link rel="stylesheet" href="/ShopVuG/css/login&register.css">
</head>
<body>
    <div class="auth-container">
        <h2>Đăng ký tài khoản</h2>
        <?php if ($register_error): ?>
            <div class="error"><?= $register_error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="text" name="username" placeholder="Tên đăng nhập" required style="width:100%; box-sizing:border-box; margin-bottom:16px;">
            <div style="position:relative; width:100%; margin-bottom:16px;">
                <input type="password" name="password" id="passwordInput" placeholder="Mật khẩu" required style="width:100%; box-sizing:border-box; padding-right:40px;">
                <span onclick="togglePassword('passwordInput', 'eyeIcon1')" style="position:absolute; right:12px; top:50%; transform:translateY(-50%); cursor:pointer; color:#888; font-size:1.2rem;">
                    <i id="eyeIcon1" class="fas fa-eye"></i>
                </span>
            </div>
            <div style="position:relative; width:100%; margin-bottom:16px;">
                <input type="password" name="confirm_password" id="confirmPasswordInput" placeholder="Nhập lại mật khẩu" required style="width:100%; box-sizing:border-box; padding-right:40px;">
                <span onclick="togglePassword('confirmPasswordInput', 'eyeIcon2')" style="position:absolute; right:12px; top:50%; transform:translateY(-50%); cursor:pointer; color:#888; font-size:1.2rem;">
                    <i id="eyeIcon2" class="fas fa-eye"></i>
                </span>
            </div>
            <button type="submit" name="register">Đăng ký</button>
        </form>
        <p>Đã có tài khoản? <a href="login.php">Đăng nhập ngay</a></p>
    </div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
<script>
function togglePassword(inputId, iconId) {
    var input = document.getElementById(inputId);
    var icon = document.getElementById(iconId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>
</html>