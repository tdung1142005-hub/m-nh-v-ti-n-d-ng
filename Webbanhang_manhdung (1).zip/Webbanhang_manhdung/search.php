<?php
session_start();
include 'config.php';

$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$products = [];

if ($keyword === '') {
    // Nếu không nhập từ khóa, lấy tất cả sản phẩm
    $stmt = $db->query("SELECT * FROM products");
    $products = $stmt->fetchAll();
} else {
    // Tìm sản phẩm có tên bắt đầu bằng từ khóa (không phân biệt hoa thường)
    $stmt = $db->prepare("SELECT * FROM products WHERE name LIKE ?");
    $stmt->execute([$keyword . '%']);
    $products = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kết quả tìm kiếm: <?= htmlspecialchars($keyword) ?></title>
    <link rel="stylesheet" href="/ShopVuG/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="header">
        <div class="logo">
            <i class="fas fa-mobile-alt"></i>
            <span>Phone Store</span>
        </div>
        <form class="search-bar" action="search.php" method="get">
            <input type="text" name="q" placeholder="Tìm kiếm sản phẩm..." value="<?= htmlspecialchars($keyword) ?>" required>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
        <div style="display: flex; align-items: center; gap: 24px;">
            <div class="cart-icon">
                <a href="cart/cart.php">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count">
                        <?= isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0 ?>
                    </span>
                </a>
            </div>
        </div>
    </header>
    <section class="product-section">
        <h2 class="section-title">Kết quả tìm kiếm cho: "<?= htmlspecialchars($keyword) ?>"</h2>
        <div class="product-grid">
            <?php if ($keyword === ''): ?>
                <div style="padding:32px; color:#888;">Vui lòng nhập từ khóa tìm kiếm.</div>
            <?php elseif (empty($products)): ?>
                <div style="padding:32px; color:#888;">Không tìm thấy sản phẩm nào phù hợp.</div>
            <?php else: ?>
                <?php foreach ($products as $row): ?>
                    <div class="product-card">
                        <div class="product-badge">-10%</div>
                        <a href="product_detail.php?id=<?= $row['id'] ?>">
                            <img src="images/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="product-image">
                        </a>
                        <div class="product-info">
                            <a href="product_detail.php?id=<?= $row['id'] ?>" style="text-decoration:none;">
                                <h3 class="product-name"><?= htmlspecialchars($row['name']) ?></h3>
                            </a>
                            <p class="product-desc"><?= htmlspecialchars($row['description']) ?></p>
                            <div class="price-box">
                                <span class="current-price"><?= number_format($row['price'], 0, ',', '.') ?> ₫</span>
                                <span class="old-price"><?= number_format($row['price'] * 1.1, 0, ',', '.') ?> ₫</span>
                            </div>
                            <a href="#" class="add-to-cart-btn" data-id="<?= $row['id'] ?>">
                                <i class="fas fa-cart-plus"></i>
                                <span>Thêm vào giỏ</span>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
    <div style="display: flex; justify-content: center; margin: 40px 0;">
        <a href="index.php" style="background: linear-gradient(90deg, #6e8efb 0%, #a777e3 100%); color: #fff; padding: 14px 36px; border-radius: 8px; font-weight: bold; font-size: 1.1rem; text-decoration: none; box-shadow: 0 2px 8px rgba(110,68,255,0.10); transition: background 0.18s;">&#8592; Quay về trang chủ</a>
    </div>
    <script src="cart.js"></script>
</body>
</html>