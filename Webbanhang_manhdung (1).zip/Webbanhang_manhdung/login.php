<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Đăng nhập</title>
    <link rel="stylesheet" href="/ShopVuG/css/login&register.css">
</head>
<body>
    <div class="auth-container">
        <h2>Đăng nhập</h2>
        <?php if (isset($login_error)): ?>
            <div class="error"><?= $login_error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="text" name="username" placeholder="Tên đăng nhập" required style="width:100%; box-sizing:border-box; margin-bottom:16px;">
            <div style="position:relative; width:100%; margin-bottom:16px;">
                <input type="password" name="password" id="passwordInput" placeholder="Mật khẩu" required style="width:100%; box-sizing:border-box; padding-right:40px;">
                <span onclick="togglePassword()" style="position:absolute; right:12px; top:50%; transform:translateY(-50%); cursor:pointer; color:#888; font-size:1.2rem;">
                    <i id="eyeIcon" class="fas fa-eye"></i>
                </span>
            </div>
            <button type="submit" name="login">Đăng nhập</button>
        </form>
        <p>Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a></p>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <script>
    function togglePassword() {
        var input = document.getElementById('passwordInput');
        var icon = document.getElementById('eyeIcon');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
    </script>
</body>
</html>

<?php
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $stmt = $db->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $username
        ];
        $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
        header("Location: $redirect");
        exit;
    } else {
        $login_error = "Thông tin đăng nhập không chính xác";
    }
}
?>