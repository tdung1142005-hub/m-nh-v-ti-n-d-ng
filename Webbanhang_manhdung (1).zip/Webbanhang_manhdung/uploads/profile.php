<?php
session_start();
include '../config.php';

// Lấy thông tin user hiện tại
$user_id = $_SESSION['user']['id'];
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Xử lý cập nhật thông tin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $avatar = isset($user['avatar']) ? $user['avatar'] : '';

    // Xử lý upload ảnh nếu có
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
        $avatar = 'uploads/avatar_' . $user_id . '.' . $ext;
        move_uploaded_file($_FILES['avatar']['tmp_name'], '../' . $avatar); // Lưu ra ngoài thư mục uploads
    }

    $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, phone = ?, address = ?, avatar = ? WHERE id = ?");
    $stmt->execute([$name, $email, $phone, $address, $avatar, $user_id]);
    // Cập nhật lại session nếu cần
    $_SESSION['user']['username'] = $name;
    $_SESSION['user']['avatar'] = $avatar;
    $_SESSION['user']['phone'] = $phone;
    $_SESSION['user']['address'] = $address;
    header("Location: profile.php?success=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thông tin tài khoản</title>
    <link rel="stylesheet" href="../style.css">
    <style>
    .modal-bg {
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; z-index: 9999;
    }
    .modal-content {
        background: #fff;
        border-radius: 18px;
        padding: 36px 32px 28px 32px;
        min-width: 340px;
        max-width: 95vw;
        box-shadow: 0 8px 32px rgba(80,80,120,0.18);
        position: relative;
        text-align: center;
        margin: 0 auto;
    }
    .modal-content img.avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        object-fit: cover;
        margin-bottom: 18px;
        border: 3px solid #a777e3;
        background: #f5f5f7;
        box-shadow: 0 2px 8px rgba(80,80,120,0.10);
    }
    .modal-content input[type="text"],
    .modal-content input[type="email"] {
        width: 95%;
        padding: 10px;
        margin: 10px 0;
        border-radius: 8px;
        border: 1.5px solid #ccc;
        font-size: 1.05rem;
    }
    .modal-content input[type="file"] {
        margin: 10px 0;
    }
    .modal-content button,
    .modal-content a.btn-back {
        margin-top: 16px;
        padding: 12px 28px;
        border-radius: 8px;
        border: none;
        background: #6e8efb;
        color: #fff;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        font-size: 1.05rem;
        transition: background 0.2s;
    }
    .modal-content a.btn-back {
        background: #888;
        margin-left: 10px;
    }
    .modal-content button:hover {
        background: #a777e3;
    }
    .close-modal {
        position: absolute;
        top: 14px;
        right: 22px;
        font-size: 1.7rem;
        color: #888;
        cursor: pointer;
    }
    .hidden-file-input {
        display: none;
    }
    .file-input-wrapper {
        margin: 10px 0;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        gap: 10px;
    }
    .custom-file-label {
        display: inline-block;
        background: #f0f0f0;
        color: #333;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 1rem;
        transition: background 0.2s;
        flex-shrink: 0;
    }
    .custom-file-label:hover {
        background: #e0e0e0;
    }
    #file-name {
        font-size: 0.95rem;
        color: #555;
        flex-grow: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: left;
    }
    </style>
</head>
<body>
    <div class="modal-bg" id="profileModal">
        <div class="modal-content">
            <span class="close-modal" onclick="window.location.href='../index.php'">&times;</span>
            <h2>Thông tin tài khoản</h2>
            <?php
            // Hiển thị ảnh đại diện đã upload (nếu có), luôn là hình tròn
            // Thêm tham số ?v=time() để chống cache
            $avatar_src = !empty($user['avatar']) && file_exists(__DIR__ . '/../' . $user['avatar']) ?
                          '../' . htmlspecialchars($user['avatar']) . '?v=' . time() :
                          'https://ui-avatars.com/api/?name=' . urlencode($user['username']) . '&background=6e8efb&color=fff';
            echo '<img class="avatar" src="' . $avatar_src . '" alt="Avatar">';
            ?>
            <form method="POST" enctype="multipart/form-data">
                <input type="text" name="name" value="<?= htmlspecialchars($user['name'] ?? $user['username']) ?>" placeholder="Tên hiển thị" required><br>
                <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" placeholder="Email"><br>
                <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="Số điện thoại"><br>
                <input type="text" name="address" value="<?= htmlspecialchars($user['address'] ?? '') ?>" placeholder="Địa chỉ"><br>
                
                <!-- Custom file input -->
                <div class="file-input-wrapper">
                    <input type="file" name="avatar" id="avatarUpload" accept="image/*" class="hidden-file-input">
                    <label for="avatarUpload" class="custom-file-label">
                        <i class="fas fa-camera"></i> Chọn ảnh đại diện
                    </label>
                    <span id="file-name"></span>
                </div>

                <button type="submit">Cập nhật</button>
                <a href="../index.php" class="btn-back">Trở về trang chủ</a>
            </form>
            <?php if (isset($_GET['success'])): ?>
                <div style="color:green; margin-top:10px;">Cập nhật thành công!</div>
            <?php endif; ?>
        </div>
    </div>
</body>
<script>
    // Hiển thị tên file đã chọn
    document.getElementById('avatarUpload').addEventListener('change', function() {
        var fileName = this.files[0] ? this.files[0].name : '';
        document.getElementById('file-name').textContent = fileName;
    });
</script>
</html>
